/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.topologicalsort;
import java.util.List;
/**
 *
 * @author NAME
 */
public class RelationList {
    public List<Relation> inList;

    public List<Relation> getInList() {
        return inList;
    }

    public void setInList(List<Relation> inList) {
        this.inList = inList;
    }
    
    
}
